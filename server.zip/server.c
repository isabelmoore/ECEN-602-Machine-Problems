#include <sys/socket.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <netinet/in.h>
#include <errno.h>
#include <arpa/inet.h>
#include <unistd.h>


int writen(int descriptor, char data[], int dataLength) { //readline
    int bytes_sent = 0; // how much bytes sent

    while (bytes_sent < dataLength) {
        int n = send(descriptor, data + bytes_sent, dataLength - bytes_sent, 0); // bytes successfully bytes_sent to buffer 
        if (n == -1) {
            if (errno == EINTR) {
                // handle interrupt during sending
                printf("Server: Write interrupted. Retrying\n");
                continue;
            }
            
            perror("Server: Write Error");  // error of sending
            return -1;
        }

        bytes_sent += n;
    }
    return bytes_sent;
}

int readline(int descriptor, char data[], int maxLength) {
    // receive data
    int n = recv(descriptor, data, maxLength, 0);
    if (n == -1) {
        perror("Server: Read Error");
        return -1;
    }
    // null terminate string
    data[n] = '\0';
    return n;
}

void handle_client(int client_socket) {
    char msg[1024];
    int msg_length;

    // processing client messages
    while ((msg_length = readline(client_socket, msg, sizeof(msg))) > 0) {
        printf("Server: Received Message: %s\n", msg);
        if (send_message(client_socket, msg, msg_length) == -1) {
            printf("Server: Error Echoing Message\n"); // if message cannot be echoed back
            break;
        }
    }

    printf("Server: Client Disconnected\n");
    close(client_socket);
}

void start_server(int port) {
    int server_socket, client_socket;
    struct sockaddr_in server_addr, client_addr;
    socklen_t addr_size = sizeof(struct sockaddr_in);
    int yes = 1;

    // create server socket
    server_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (server_socket == -1) {
        perror("Server: Socket Error");
        exit(EXIT_FAILURE);
    }

    // attaching socket to port
    if (setsockopt(server_socket, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(int)) == -1) {
        perror("Server: Setsockopt Error");
        exit(EXIT_FAILURE);
    }

    // setting Server address
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(port);
    server_addr.sin_addr.s_addr = INADDR_ANY;
    memset(&server_addr.sin_zero, 0, sizeof(server_addr.sin_zero));

    // bind socket
    if (bind(server_socket, (struct sockaddr *)&server_addr, sizeof(server_addr)) == -1) {
        perror("Server: Bind Error");
        exit(EXIT_FAILURE);
    }

    // for connections
    if (listen(server_socket, 10) == -1) {
        perror("Server: Listen Error");
        exit(EXIT_FAILURE);
    }

    printf("Server: Listening on Port %d\n", port);  // server is ready

    // incoming connections
    while (1) {
        client_socket = accept(server_socket, (struct sockaddr *)&client_addr, &addr_size);
        if (client_socket == -1) {
            perror("Server: Accept Error");
            continue;
        }

        int pid = fork();
        if (pid == 0) {  // child process
            close(server_socket);
            handle_client(client_socket);
            exit(0);
        } else if (pid > 0) {
            close(client_socket); // close client socket in parent
        } else {
            perror("Server: Fork Error");
        }
    }
}

int main(int argc, char *argv[]) {
    if (argc < 2) {
        printf("Please specify the port number\n");
        return EXIT_FAILURE;
    }

    int port = atoi(argv[1]);
    start_server(port);
    return 0;
}
