#include <errno.h>
#include <sys/socket.h>
#include <stdio.h>
#include <string.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <stdlib.h>
#include <unistd.h>


int create_socket() {
    int sock_fd = socket(AF_INET, SOCK_STREAM, 0); // socket descriptor
    if (sock_fd == -1) {
        perror("Creating Socket Failed");
        exit(EXIT_FAILURE);
    }
    return sock_fd;
}

void connect_to_server(int socket_fd, const char *server_ip, int port) {
    struct sockaddr_in serveraddr;
    serveraddr.sin_family = AF_INET;  // address family to internet
    serveraddr.sin_port = htons(port);  // port, converting from host to network byte order
    serveraddr.sin_addr.s_addr = inet_addr(server_ip);  // IP address

    if (connect(socket_fd, (struct sockaddr *)&serveraddr, sizeof(serveraddr)) == -1) {
        perror("Connecting to Eerver Failed");
        exit(EXIT_FAILURE);
    }
    puts("Connection Established");
}

// messages to/from the server
void send_and_receive_messages(int socket_fd) {
    char send_buffer[100];   
    char receive_buffer[100];  

    while (1) {
        printf("Enter Message: ");
        if (fgets(send_buffer, sizeof(send_buffer), stdin) == NULL || feof(stdin)) {
            puts("EOF encountered, Exiting");
            break;
        }

        if (send(socket_fd, send_buffer, strlen(send_buffer), 0) == -1) {
            perror("Sending Message Failed");
            continue;
        }

        int bytes_received = recv(socket_fd, receive_buffer, sizeof(receive_buffer) - 1, 0);
        if (bytes_received > 0) {
            receive_buffer[bytes_received] = '\0';  // null
            printf("Received: %s", receive_buffer);
        } else if (bytes_received == 0) {
            puts("Server Closed the Connection");
            break;
        } else {
            perror("Receiving Message Failed");
        }
    }
}

// socket cleaned by closing connection
void cleanup(int socket_fd) {
    close(socket_fd);
    puts("Connection Closed");
}

int main(int argc, char* argv[]) {
    if (argc < 3) {
        fprintf(stderr, "Usage: %s <server_ip> <port>\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    int server_port = atoi(argv[2]);  // parse port number from command line
    int socket_fd = create_socket();  // create socket

    connect_to_server(socket_fd, argv[1], server_port);  // establish connection to server
    send_and_receive_messages(socket_fd);  
    cleanup(socket_fd);  

    return 0;
}