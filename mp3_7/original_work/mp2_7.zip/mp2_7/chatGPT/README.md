#Run the following command to compile both the server and client:
make
#To run the server, use:
make run-server
#To run the client, open another terminal and use:
make run-client
#To clean up the compiled files, use:
make clean
